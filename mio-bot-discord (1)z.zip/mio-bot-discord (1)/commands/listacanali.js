// commands/listacanali.js
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('listacanali')
    .setDescription('Mostra la lista dei canali del server'),
  async execute(interaction) {
    const channels = interaction.guild.channels.cache
      .filter(c => c.type === 0 || c.type === 2) // Solo testo e voce
      .map(c => `${c.type === 0 ? '📝' : '🔊'} ${c.name} (ID: ${c.id})`)
      .join('\n');
    await interaction.reply({
      content: channels.length > 0 ? `Canali trovati:\n${channels}` : 'Nessun canale trovato.',
      ephemeral: true
    });
  },
};

// Comando disabilitato
module.exports = {};
