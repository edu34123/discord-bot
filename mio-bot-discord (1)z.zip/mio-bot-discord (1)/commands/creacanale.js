// Comando disabilitato
module.exports = {};
