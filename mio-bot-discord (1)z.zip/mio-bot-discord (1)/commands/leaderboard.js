// commands/leaderboard.js
const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const LEVELS_FILE = path.join(__dirname, '../data/levels.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('leaderboard')
    .setDescription('Mostra la classifica dei livelli XP'),
  async execute(interaction) {
    let levels = {};
    if (fs.existsSync(LEVELS_FILE)) {
      try { levels = JSON.parse(fs.readFileSync(LEVELS_FILE, 'utf8')); } catch { levels = {}; }
    }
    // Ordina per XP decrescente
    const sorted = Object.entries(levels)
      .sort((a, b) => b[1].xp - a[1].xp)
      .slice(0, 15);
    let desc = '';
    let pos = 1;
    for (const [userId, data] of sorted) {
      const member = await interaction.guild.members.fetch(userId).catch(() => null);
      let name = member ? member.user.tag : `account${userId}`;
      // Colore personalizzato per ruoli
      let color = null;
      if (member && member.roles && interaction.guild && interaction.guild.roles) {
        // Scegli il colore del ruolo più alto (escludendo @everyone)
        const colored = member.roles.cache.filter(r => r.color && r.id !== interaction.guild.id);
        if (colored.size > 0) {
          color = colored.sort((a, b) => b.position - a.position).first().color;
        }
      }
      desc += `${pos}. ${name}: Level ${data.level} - ${data.xp} XP\n`;
      pos++;
    }
    const embed = new EmbedBuilder()
      .setTitle('Live Leaderboard')
      .setDescription('Find all the users levels here. Updated every time.\n\n**Leaderboard**\n' + desc)
      .setColor(0x00BFFF)
      .setTimestamp();
    await interaction.reply({ embeds: [embed], ephemeral: false });
  }
};
