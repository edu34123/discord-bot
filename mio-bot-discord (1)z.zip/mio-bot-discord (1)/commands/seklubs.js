// commands/seklubs.js
const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('seklubs')
    .setDescription('Mostra info e comandi Seklubs'),
  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setTitle('🗝️ Seklubs!')
      .setDescription(
        '***Cosa sono?***\n' +
        '• Vi presentiamo i **Seklubs**: sono i klubs di Sekiro, stanze **private** dove puoi decidere tu chi far entrare o meno!\n\n' +
        '***Che permessi mi servono per crearla?***\n' +
        '• Puoi vedere i ruoli con i permessi cliccando il bottone elencato sotto l\'embed.\n\n' +
        '**Comandi:**\n' +
        '`>crea [nome]`\n' +
        '`>modifica [nome]`\n' +
        '`>blocca` (accesso a solo trustati e creatore)\n' +
        '`>sblocca` (accesso a tutti)\n' +
        '`>trust [@utente]` (consente accesso)\n' +
        '`>elimina` (rimuove klubs)'
      )
      .setImage('https://i.imgur.com/1d1ab3313a88ee5e6f4674f37c32a238.png')
      .setColor(0x23272A);
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('seklubs_roles')
        .setLabel('📂 Ruoli Autorizzati')
        .setStyle(ButtonStyle.Secondary)
    );
    await interaction.reply({ embeds: [embed], components: [row] });
  }
};
