// commands/rrole.js
const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('rrole')
    .setDescription('Crea un messaggio per assegnare ruoli tramite menu a tendina')
    .addStringOption(opt =>
      opt.setName('titolo').setDescription('Titolo embed').setRequired(true))
    .addStringOption(opt =>
      opt.setName('descrizione').setDescription('Descrizione embed').setRequired(true))
    .addStringOption(opt =>
      opt.setName('ruoli').setDescription('Ruoli separati da virgola (ID:Nome)').setRequired(true)),
  async execute(interaction) {
    const titolo = interaction.options.getString('titolo');
    const descrizione = interaction.options.getString('descrizione');
    const ruoliRaw = interaction.options.getString('ruoli');
    // ruoliRaw: "123456789:Ruolo1,987654321:Ruolo2"
    const ruoli = ruoliRaw.split(',').map(r => {
      const [id, label] = r.split(':');
      return { id: id.trim(), label: (label || id).trim() };
    });
    const embed = new EmbedBuilder()
      .setTitle(titolo)
      .setDescription(descrizione)
      .setColor(0x00BFFF);
    const menu = new StringSelectMenuBuilder()
      .setCustomId('reactionrole')
      .setPlaceholder('Scegli un ruolo...')
      .addOptions(ruoli.map(r => ({ label: r.label, value: r.id })));
    const row = new ActionRowBuilder().addComponents(menu);
    await interaction.reply({ embeds: [embed], components: [row] });
  }
};
