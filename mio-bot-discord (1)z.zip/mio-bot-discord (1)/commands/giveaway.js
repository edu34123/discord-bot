const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

const activeGiveaways = {};

module.exports = {
  data: new SlashCommandBuilder()
    .setName('giveaway')
    .setDescription('Crea un giveaway')
    .addIntegerOption(option =>
      option.setName('durata')
        .setDescription('Durata in minuti')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('premio')
        .setDescription('Premio del giveaway')
        .setRequired(true)),
  async execute(interaction) {
    if (!interaction.isChatInputCommand()) return;
    const durata = interaction.options.getInteger('durata');
    const premio = interaction.options.getString('premio');
    if (activeGiveaways[interaction.channel.id]) {
      return interaction.reply({ content: '❌ C\'è già un giveaway attivo in questo canale!', ephemeral: true });
    }
    const embed = new EmbedBuilder()
      .setTitle('🎉 GIVEAWAY!')
      .setDescription(`Premio: **${premio}**\nClicca su "Partecipa 🎉" per partecipare!\nDurata: ${durata} minuti`)
      .setColor(0xF1C40F)
      .setTimestamp();
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('giveaway_enter')
        .setLabel('Partecipa 🎉')
        .setStyle(ButtonStyle.Success)
    );
    const msg = await interaction.channel.send({ embeds: [embed], components: [row] });
    activeGiveaways[interaction.channel.id] = { msg, users: new Set() };
    await interaction.reply({ content: 'Giveaway avviato!', ephemeral: true });
    setTimeout(async () => {
      const data = activeGiveaways[interaction.channel.id];
      if (!data) return;
      const partecipanti = Array.from(data.users);
      if (partecipanti.length === 0) {
        await msg.edit({ embeds: [embed.setDescription('Nessun partecipante!')], components: [] });
        await interaction.channel.send('❌ Giveaway terminato: nessun vincitore.');
      } else {
        const vincitore = partecipanti[Math.floor(Math.random() * partecipanti.length)];
        await msg.edit({ embeds: [embed.setDescription(`Vincitore: <@${vincitore}>!\nPremio: **${premio}**`)], components: [] });
        await interaction.channel.send(`🎉 Complimenti <@${vincitore}>! Hai vinto: **${premio}**`);
      }
      delete activeGiveaways[interaction.channel.id];
    }, durata * 60000);
  },
  // Listener per i pulsanti (da usare in un modulo globale se vuoi supporto multi-comando)
  onButton(interaction) {
    if (!interaction.isButton()) return;
    if (interaction.customId !== 'giveaway_enter') return;
    const data = activeGiveaways[interaction.channel.id];
    if (!data) return interaction.reply({ content: 'Giveaway non più attivo.', ephemeral: true });
    if (data.users.has(interaction.user.id)) {
      return interaction.reply({ content: 'Hai già partecipato!', ephemeral: true });
    }
    data.users.add(interaction.user.id);
    interaction.reply({ content: 'Partecipazione registrata!', ephemeral: true });
  }
};
