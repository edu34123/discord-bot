const { SlashCommandBuilder } = require('discord.js');
const config = require('../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('restart')
    .setDescription('Riavvia il bot (solo utenti autorizzati)'),
  async execute(interaction) {
    // Comando disabilitato
  },
};
