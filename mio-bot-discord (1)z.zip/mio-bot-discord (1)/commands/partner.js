const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const config = require('../config.json');

// File dove salvare le partnership (JSON semplice)
const PARTNER_FILE = path.join(__dirname, '../data/partnerships.json');

function loadPartners() {
  if (!fs.existsSync(PARTNER_FILE)) return [];
  try {
    return JSON.parse(fs.readFileSync(PARTNER_FILE, 'utf8'));
  } catch {
    return [];
  }
}
function savePartners(list) {
  fs.mkdirSync(path.dirname(PARTNER_FILE), { recursive: true });
  fs.writeFileSync(PARTNER_FILE, JSON.stringify(list, null, 2));
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('partner')
    .setDescription('Gestione partnership')
    .addSubcommand(subcommand =>
      subcommand
        .setName('add')
        .setDescription('Aggiungi una partnership')
        .addStringOption(option =>
          option.setName('nome').setDescription('Nome della community/partner').setRequired(true))
        .addStringOption(option =>
          option.setName('link').setDescription('Link di invito o riferimento').setRequired(true))
        .addStringOption(option =>
          option.setName('descrizione').setDescription('Descrizione breve della partnership').setRequired(false))
    )
    .addSubcommand(subcommand =>
      subcommand
        .setName('edit')
        .setDescription('Modifica una partnership')
        .addStringOption(option =>
          option.setName('nome').setDescription('Nome della partnership da modificare').setRequired(true))
        .addStringOption(option =>
          option.setName('nuovo_nome').setDescription('Nuovo nome').setRequired(false))
        .addStringOption(option =>
          option.setName('nuovo_link').setDescription('Nuovo link').setRequired(false))
        .addStringOption(option =>
          option.setName('nuova_descrizione').setDescription('Nuova descrizione').setRequired(false))
    )
    .addSubcommand(subcommand =>
      subcommand
        .setName('delete')
        .setDescription('Elimina una partnership')
        .addStringOption(option =>
          option.setName('nome').setDescription('Nome della partnership da eliminare').setRequired(true))
    ),
  async execute(interaction) {
    if (!interaction.isChatInputCommand()) return;
    if (interaction.commandName !== 'partner') return;
    const allowedUsers = config.allowedUsers || [];
    if (!allowedUsers.includes(interaction.user.id)) {
      return interaction.reply({ content: 'Non hai i permessi per gestire le partnership.', ephemeral: true });
    }
    const sub = interaction.options.getSubcommand();
    let partners = loadPartners();
    if (sub === 'add') {
      const nome = interaction.options.getString('nome');
      const link = interaction.options.getString('link');
      const descrizione = interaction.options.getString('descrizione') || '';
      if (partners.find(p => p.nome.toLowerCase() === nome.toLowerCase())) {
        return interaction.reply({ content: 'Esiste già una partnership con questo nome.', ephemeral: true });
      }
      partners.push({ nome, link, descrizione });
      savePartners(partners);
      // Invia embed nel canale partnership
      const channel = interaction.guild.channels.cache.get(config.partnershipChannelId);
      if (!channel) return interaction.reply({ content: 'Canale partnership non trovato.', ephemeral: true });
      const embed = new EmbedBuilder()
        .setTitle(`🤝 Nuova Partnership: ${nome}`)
        .setDescription(descrizione || 'Nessuna descrizione fornita.')
        .addFields({ name: 'Link', value: link })
        .setColor(0x00BFFF)
        .setTimestamp()
        .setFooter({ text: `Aggiunto da ${interaction.user.tag}` });
      await channel.send({ embeds: [embed] });
      await interaction.reply({ content: 'Partnership aggiunta con successo!', ephemeral: true });
    } else if (sub === 'edit') {
      const nome = interaction.options.getString('nome');
      const nuovo_nome = interaction.options.getString('nuovo_nome');
      const nuovo_link = interaction.options.getString('nuovo_link');
      const nuova_descrizione = interaction.options.getString('nuova_descrizione');
      const idx = partners.findIndex(p => p.nome.toLowerCase() === nome.toLowerCase());
      if (idx === -1) return interaction.reply({ content: 'Partnership non trovata.', ephemeral: true });
      if (nuovo_nome) partners[idx].nome = nuovo_nome;
      if (nuovo_link) partners[idx].link = nuovo_link;
      if (nuova_descrizione) partners[idx].descrizione = nuova_descrizione;
      savePartners(partners);
      await interaction.reply({ content: 'Partnership modificata!', ephemeral: true });
    } else if (sub === 'delete') {
      const nome = interaction.options.getString('nome');
      const idx = partners.findIndex(p => p.nome.toLowerCase() === nome.toLowerCase());
      if (idx === -1) return interaction.reply({ content: 'Partnership non trovata.', ephemeral: true });
      partners.splice(idx, 1);
      savePartners(partners);
      await interaction.reply({ content: 'Partnership eliminata!', ephemeral: true });
    }
  },
};
