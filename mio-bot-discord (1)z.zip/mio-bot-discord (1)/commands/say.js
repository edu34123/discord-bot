// commands/say.js
const { ChannelType } = require('discord.js');

module.exports = {
  name: 'say',
  description: 'Il bot ripete il messaggio specificato in un canale scelto',
  async execute(message, args) {
    if (!args.length) return message.reply('❌ Devi specificare un messaggio.');
    // Chiedi in che canale inviare
    await message.reply('In quale canale vuoi inviare il messaggio? Rispondi con #canale o ID. (30s)');
    const filter = m => m.author.id === message.author.id;
    try {
      const collected = await message.channel.awaitMessages({ filter, max: 1, time: 30000, errors: ['time'] });
      const reply = collected.first();
      let channel = null;
      // Cerca canale per mention o ID
      const match = reply.content.match(/<#(\d+)>/);
      if (match) {
        channel = message.guild.channels.cache.get(match[1]);
      } else if (/^\d+$/.test(reply.content)) {
        channel = message.guild.channels.cache.get(reply.content);
      }
      if (!channel || channel.type !== ChannelType.GuildText) {
        return message.reply('❌ Canale non valido o non testuale.');
      }
      const text = args.join(' ');
      await channel.send(text);
      await message.reply(`Messaggio inviato in ${channel}`);
    } catch {
      await message.reply('⏰ Tempo scaduto o errore.');
    }
  },
};
