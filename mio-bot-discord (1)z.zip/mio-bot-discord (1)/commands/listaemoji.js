// commands/listaemoji.js
// Comando disabilitato
module.exports = {};
