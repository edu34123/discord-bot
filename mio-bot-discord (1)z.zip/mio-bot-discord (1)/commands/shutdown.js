const { SlashCommandBuilder } = require('discord.js');
const config = require('../config.json');

// Comando disabilitato
module.exports = {};
