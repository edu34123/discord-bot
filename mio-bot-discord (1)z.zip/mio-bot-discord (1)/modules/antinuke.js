// modules/antinuke.js
// Anti-nuke: limita azioni sospette come eliminazione/creazione massiva di canali, ban di massa, ecc.

const LIMIT = 5; // Numero massimo di azioni consentite in 10 secondi
const TIME = 10000; //  10 secondi
const actions = {};

function trackAction(userId, type) {
  if (!actions[userId]) actions[userId] = {};
  if (!actions[userId][type]) actions[userId][type] = [];
  actions[userId][type].push(Date.now());
  // Mantieni solo le azioni negli ultimi TIME ms
  actions[userId][type] = actions[userId][type].filter(ts => Date.now() - ts < TIME);
  return actions[userId][type].length;
}

module.exports = (client, config) => {
  // Protezione: creazione canali
  client.on('channelCreate', async (channel) => {
    const audit = await channel.guild.fetchAuditLogs({ type: 10, limit: 1 });
    const entry = audit.entries.first();
    if (!entry) return;
    const userId = entry.executor.id;
    if (trackAction(userId, 'create') > LIMIT) {
      try {
        await channel.guild.members.ban(userId, { reason: 'Anti-nuke: creazione canali sospetta' });
        await channel.guild.owner.send(`⚠️ Utente <@${userId}> bannato per creazione massiva di canali.`).catch(() => {});
      } catch {}
    }
  });
  // Protezione: eliminazione canali
  client.on('channelDelete', async (channel) => {
    const audit = await channel.guild.fetchAuditLogs({ type: 12, limit: 1 });
    const entry = audit.entries.first();
    if (!entry) return;
    const userId = entry.executor.id;
    if (trackAction(userId, 'delete') > LIMIT) {
      try {
        await channel.guild.members.ban(userId, { reason: 'Anti-nuke: eliminazione canali sospetta' });
        await channel.guild.owner.send(`⚠️ Utente <@${userId}> bannato per eliminazione massiva di canali.`).catch(() => {});
      } catch {}
    }
  });
  // Protezione: ban di massa
  client.on('guildBanAdd', async (ban) => {
    const audit = await ban.guild.fetchAuditLogs({ type: 22, limit: 1 });
    const entry = audit.entries.first();
    if (!entry) return;
    const userId = entry.executor.id;
    if (trackAction(userId, 'ban') > LIMIT) {
      try {
        await ban.guild.members.ban(userId, { reason: 'Anti-nuke: ban di massa' });
        await ban.guild.owner.send(`⚠️ Utente <@${userId}> bannato per ban di massa.`).catch(() => {});
      } catch {}
    }
  });
};
