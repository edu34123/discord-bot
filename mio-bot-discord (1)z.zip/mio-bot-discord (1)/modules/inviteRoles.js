// modules/inviteRoles.js
// Assegna ruoli in base agli inviti fatti e ruoli automatici ai nuovi membri

module.exports = (client, config) => {
  // Mappa: numero inviti -> ruolo
  const inviteRoles = config.inviteRoles || {
    1: null, // ID ruolo per 1 invito
    3: null, // ID ruolo per 3 inviti
    5: null,
    10: null,
    50: null,
    100: null
  };
  const autoRoles = config.autoRoles || [];
  let invitesCache = {};

  client.on('ready', async () => {
    for (const guild of client.guilds.cache.values()) {
      invitesCache[guild.id] = await guild.invites.fetch().catch(() => new Map());
    }
  });

  client.on('inviteCreate', invite => {
    if (!invitesCache[invite.guild.id]) invitesCache[invite.guild.id] = new Map();
    invitesCache[invite.guild.id].set(invite.code, invite);
  });
  client.on('inviteDelete', invite => {
    if (invitesCache[invite.guild.id]) invitesCache[invite.guild.id].delete(invite.code);
  });

  // Quando entra un nuovo membro
  client.on('guildMemberAdd', async member => {
    // Ruoli automatici
    for (const roleId of autoRoles) {
      if (member.guild.roles.cache.has(roleId)) {
        await member.roles.add(roleId).catch(() => {});
      }
    }
    // Inviti
    const newInvites = await member.guild.invites.fetch().catch(() => new Map());
    const oldInvites = invitesCache[member.guild.id] || new Map();
    let inviter = null;
    for (const [code, invite] of newInvites) {
      const oldUses = oldInvites.get(code)?.uses || 0;
      if (invite.uses > oldUses) inviter = invite.inviter;
    }
    invitesCache[member.guild.id] = newInvites;
    if (inviter) {
      // Conta quanti ne ha invitati
      inviter.inviteCount = (inviter.inviteCount || 0) + 1;
      // Assegna ruoli in base al numero di inviti
      for (const [count, roleId] of Object.entries(inviteRoles)) {
        if (roleId && inviter.inviteCount >= parseInt(count)) {
          if (member.guild.roles.cache.has(roleId)) {
            const gMember = await member.guild.members.fetch(inviter.id).catch(() => null);
            if (gMember && !gMember.roles.cache.has(roleId)) {
              await gMember.roles.add(roleId).catch(() => {});
            }
          }
        }
      }
    }
  });
};
