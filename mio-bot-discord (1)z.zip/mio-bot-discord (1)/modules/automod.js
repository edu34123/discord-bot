// modules/automod.js
// Semplice automod: elimina messaggi con parole vietate e avvisa l'utente

const bannedWords = [
  'Negro',
  'fag',
  'foggot',
  'Troia',
  'discord.gg/',
  'discordapp.com/', // blocca inviti
  // aggiungi altre parole/frasi vietate qui
];

module.exports = (client, config) => {
  client.on('messageCreate', async (message) => {
    if (message.author.bot) return;
    if (!message.guild) return;
    const content = message.content.toLowerCase();
    const found = bannedWords.find(word => content.includes(word));
    if (found) {
      try {
        await message.delete();
        // Elimina l'ultimo messaggio di avviso del bot (stesso canale)
        const messages = await message.channel.messages.fetch({ limit: 10 });
        const lastWarn = messages.find(m =>
          m.author.id === client.user.id &&
          m.content &&
          m.content.includes('il tuo messaggio è stato rimosso per contenuto non consentito.')
        );
        if (lastWarn) {
          try { await lastWarn.delete(); } catch {}
        }
        await message.channel.send({
          content: `⚠️ <@${message.author.id}> il tuo messaggio è stato rimosso per contenuto non consentito.`,
        });
      } catch (err) {
        console.error('Errore automod:', err);
      }
    }
  });
};
