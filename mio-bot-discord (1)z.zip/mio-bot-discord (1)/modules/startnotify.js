// modules/startnotify.js
// Invia una notifica in un canale specifico ogni volta che il bot si avvia

module.exports = (client, config) => {
  client.once('ready', async () => {
    console.log('[startnotify] Evento ready ricevuto, provo a inviare la notifica...');
    try {
      const channelId = config.startNotifyChannelId || config.welcomeChannelId;
      console.log('[startnotify] ChannelId scelto:', channelId);
      const channel = await client.channels.fetch(channelId);
      if (!channel) {
        console.error('[startnotify] Canale non trovato!');
        return;
      }
      if (!channel.isTextBased()) {
        console.error('[startnotify] Il canale non è testuale!');
        return;
      }
      await channel.send('✅ Il bot è stato avviato ed è ora online!');
      console.log('[startnotify] Notifica inviata con successo!');
    } catch (err) {
      console.error('[startnotify] Errore invio notifica avvio:', err);
    }
  });
};
