// modules/advancedLogger.js
// Log avanzato di eventi membri: join/leave vocale, mute/unmute, modifica/elimina messaggi, stream

module.exports = (client, config) => {
  const logChannelId = config.logChannelId; // ID canale testuale per i log
  if (!logChannelId) return;

  function sendLog(guild, msg) {
    const channel = guild.channels.cache.get(logChannelId);
    if (channel && channel.isTextBased()) channel.send(msg);
  }

  // Log join/leave/mute/unmute/stream in vocale
  client.on('voiceStateUpdate', (oldState, newState) => {
    const member = newState.member;
    if (!member || !member.guild) return;
    // Join vocale
    if (!oldState.channelId && newState.channelId) {
      sendLog(member.guild, `🔊 <@${member.id}> è entrato in vocale: <#${newState.channelId}>`);
    }
    // Leave vocale
    if (oldState.channelId && !newState.channelId) {
      sendLog(member.guild, `🔇 <@${member.id}> è uscito dalla vocale: <#${oldState.channelId}>`);
    }
    // Mute/unmute
    if (oldState.selfMute !== newState.selfMute) {
      sendLog(member.guild, `${newState.selfMute ? '🔇' : '🔊'} <@${member.id}> ${newState.selfMute ? 'si è mutato' : 'si è smutato'} in <#${newState.channelId || oldState.channelId}>`);
    }
    // Stream
    if (!oldState.streaming && newState.streaming) {
      sendLog(member.guild, `📺 <@${member.id}> ha avviato la stream in <#${newState.channelId}>`);
    }
    if (oldState.streaming && !newState.streaming) {
      sendLog(member.guild, `🛑 <@${member.id}> ha terminato la stream in <#${oldState.channelId}>`);
    }
  });

  // Log modifica messaggi
  client.on('messageUpdate', (oldMsg, newMsg) => {
    if (!oldMsg.guild || oldMsg.author.bot) return;
    if (oldMsg.content !== newMsg.content) {
      sendLog(oldMsg.guild, `✏️ Messaggio modificato da <@${oldMsg.author.id}> in <#${oldMsg.channel.id}>\nPrima: ${oldMsg.content}\nDopo: ${newMsg.content}`);
    }
  });

  // Log elimina messaggi
  client.on('messageDelete', (msg) => {
    if (!msg.guild || msg.author?.bot) return;
    sendLog(msg.guild, `❌ Messaggio eliminato da <@${msg.author.id}> in <#${msg.channel.id}>:\n${msg.content}`);
  });

  // Log join server
  client.on('guildMemberAdd', member => {
    sendLog(member.guild, `✅ <@${member.id}> è entrato nel server!`);
  });

  // Log leave server
  client.on('guildMemberRemove', member => {
    sendLog(member.guild, `❌ <@${member.id}> è uscito dal server!`);
  });

  // Log inviti (quando un membro invita un altro)
  // Richiede fetch degli inviti all'avvio e confronto
  let invitesCache = {};
  client.on('ready', async () => {
    for (const guild of client.guilds.cache.values()) {
      invitesCache[guild.id] = await guild.invites.fetch().catch(() => new Map());
    }
  });
  client.on('guildMemberAdd', async member => {
    const newInvites = await member.guild.invites.fetch().catch(() => new Map());
    const oldInvites = invitesCache[member.guild.id] || new Map();
    let inviter = null;
    for (const [code, invite] of newInvites) {
      const oldUses = oldInvites.get(code)?.uses || 0;
      if (invite.uses > oldUses) inviter = invite.inviter;
    }
    invitesCache[member.guild.id] = newInvites;
    if (inviter) {
      sendLog(member.guild, `🔗 <@${inviter.id}> ha invitato <@${member.id}> nel server!`);
    }
  });
  client.on('inviteCreate', invite => {
    if (!invitesCache[invite.guild.id]) invitesCache[invite.guild.id] = new Map();
    invitesCache[invite.guild.id].set(invite.code, invite);
  });
  client.on('inviteDelete', invite => {
    if (invitesCache[invite.guild.id]) invitesCache[invite.guild.id].delete(invite.code);
  });

  // Log modifica ruoli utente
  client.on('guildMemberUpdate', (oldMember, newMember) => {
    const oldRoles = oldMember.roles.cache.map(r => r.id).sort().join(',');
    const newRoles = newMember.roles.cache.map(r => r.id).sort().join(',');
    if (oldRoles !== newRoles) {
      sendLog(newMember.guild, `🛡️ Ruoli modificati per <@${newMember.id}>\nPrima: ${oldMember.roles.cache.map(r => r.name).join(', ')}\nDopo: ${newMember.roles.cache.map(r => r.name).join(', ')}`);
    }
  });

  // Log modifica server
  client.on('guildUpdate', (oldGuild, newGuild) => {
    let changes = [];
    if (oldGuild.name !== newGuild.name) changes.push(`Nome: "${oldGuild.name}" → "${newGuild.name}"`);
    if (oldGuild.icon !== newGuild.icon) changes.push('Icona cambiata');
    if (oldGuild.banner !== newGuild.banner) changes.push('Banner cambiato');
    if (changes.length > 0) {
      sendLog(newGuild, `⚙️ Impostazioni server modificate:\n${changes.join('\n')}`);
    }
  });
};
