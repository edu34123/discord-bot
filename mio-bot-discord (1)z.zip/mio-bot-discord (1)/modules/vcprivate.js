// Modulo vuoto per compatibilità legacy
module.exports = (client, config) => {};
