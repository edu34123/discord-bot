// modules/memberStats.js
// Invia un messaggio con il conteggio di membri, bot e totale

module.exports = (client, config) => {
  client.on('messageCreate', async (message) => {
    if (message.author.bot) return;
    if (!config.allowedUsers.includes(message.author.id)) return;
    // (Comando !serverstats rimosso: ora le statistiche sono mostrate nei canali vocali)
  });
};
