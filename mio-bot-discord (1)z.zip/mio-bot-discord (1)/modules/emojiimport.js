// modules/emojiimport.js
// Modulo: comando testuale !importemoji <ID o nome emoji> <nome_nuovo>
// Solo allowedUsers

module.exports = (client, config) => {
  client.on('messageCreate', async (message) => {
    if (message.author.bot) return;
    if (!config.allowedUsers.includes(message.author.id)) return;
    if (!message.content.startsWith('!steamemoji ')) return;
    const args = message.content.split(' ').slice(1);
    if (args.length < 1) return message.reply('❌ Usa: !steamemoji <ID o nome emoji> [nuovo_nome]');
    const emojiQuery = args[0];
    const newName = args[1] || 'imported';
    // Cerca l'emoji in tutti i server dove il bot è presente
    let found = null;
    for (const [guildId, guild] of client.guilds.cache) {
      found = guild.emojis.cache.find(e => e.id === emojiQuery || e.name === emojiQuery);
      if (found) break;
    }
    if (!found) return message.reply('❌ Emoji non trovata in nessun server.');
    try {
      const emoji = await message.guild.emojis.create({
        attachment: found.url,
        name: newName
      });
      await message.reply(`✅ Emoji importata: <:${emoji.name}:${emoji.id}>`);
    } catch (err) {
      console.error('Errore import emoji:', err);
      await message.reply('❌ Errore durante l\'importazione. Il bot deve avere permesso di gestire emoji.');
    }
  });
};
