// modules/voiceStats.js
// Aggiorna i nomi di canali vocali per mostrare membri, bot e totale

module.exports = (client, config) => {
  // Configura gli ID dei canali vocali da aggiornare in config.json
  const stats = [
    { key: 'users', label: '👥 Membri', id: config.voiceStatsUsersId },
    { key: 'bots', label: '🤖 Bot', id: config.voiceStatsBotsId },
    { key: 'total', label: '🔢 Totale', id: config.voiceStatsTotalId },
  ];

  async function updateStats(guild) {
    const members = await guild.members.fetch();
    const total = members.size;
    const bots = members.filter(m => m.user.bot).size;
    const users = total - bots;
    for (const stat of stats) {
      const channel = guild.channels.cache.get(stat.id);
      if (channel && channel.type === 2 && channel.manageable) { // 2 = GuildVoice
        let value = 0;
        if (stat.key === 'users') value = users;
        if (stat.key === 'bots') value = bots;
        if (stat.key === 'total') value = total;
        await channel.setName(`${stat.label}: ${value}`);
      }
    }
  }

  client.on('ready', () => {
    for (const guild of client.guilds.cache.values()) {
      updateStats(guild);
    }
  });
  client.on('guildMemberAdd', member => updateStats(member.guild));
  client.on('guildMemberRemove', member => updateStats(member.guild));
};
