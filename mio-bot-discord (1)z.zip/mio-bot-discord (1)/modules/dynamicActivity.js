// modules/dynamicActivity.js
// Imposta l'attività del bot con il numero di membri o tagga l'ultimo entrato

module.exports = (client, config) => {
  // Mostra il numero di membri all'avvio e quando qualcuno entra o esce
  const updateActivity = async (guild) => {
    const members = await guild.members.fetch();
    const users = members.filter(m => !m.user.bot).size;
    client.user.setActivity(`👥 ${users} membri`, { type: 'WATCHING' });
  };

  client.on('ready', () => {
    for (const guild of client.guilds.cache.values()) {
      updateActivity(guild);
    }
  });

  client.on('guildMemberAdd', async (member) => {
    await updateActivity(member.guild);
    // Tagga il nuovo utente nell'attività per pochi secondi
    const tag = `👋 Benvenuto ${member.user.username}!`;
    client.user.setActivity(tag, { type: 'PLAYING' });
    setTimeout(() => updateActivity(member.guild), 15000); // Torna al conteggio dopo 15s
  });

  client.on('guildMemberRemove', async (member) => {
    await updateActivity(member.guild);
  });
};
