// modules/giveaway.js
// Modulo semplice per giveaway: comando !giveaway <durata_minuti> <premio>
// Solo allowedUsers

const activeGiveaways = {};

module.exports = (client, config) => {
  client.on('messageCreate', async (message) => {
    if (message.author.bot) return;
    if (!config.allowedUsers.includes(message.author.id)) return;
    if (!message.content.startsWith('!giveaway ')) return;
    const args = message.content.split(' ').slice(1);
    if (args.length < 2) return message.reply('❌ Usa: !giveaway <durata_minuti> <premio>');
    const durata = parseInt(args[0]);
    if (isNaN(durata) || durata < 1) return message.reply('❌ Durata non valida.');
    const premio = args.slice(1).join(' ');
    if (activeGiveaways[message.channel.id]) return message.reply('❌ C\'è già un giveaway attivo in questo canale!');
    const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
    const embed = new EmbedBuilder()
      .setTitle('🎉 GIVEAWAY!')
      .setDescription(`Premio: **${premio}**\nReagisci con 🎉 per partecipare!\nDurata: ${durata} minuti`)
      .setColor(0xF1C40F)
      .setTimestamp();
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('giveaway_enter')
        .setLabel('Partecipa 🎉')
        .setStyle(ButtonStyle.Success)
    );
    const msg = await message.channel.send({ embeds: [embed], components: [row] });
    activeGiveaways[message.channel.id] = { msg, users: new Set() };
    setTimeout(async () => {
      const data = activeGiveaways[message.channel.id];
      if (!data) return;
      const partecipanti = Array.from(data.users);
      if (partecipanti.length === 0) {
        await msg.edit({ embeds: [embed.setDescription('Nessun partecipante!')], components: [] });
        await message.channel.send('❌ Giveaway terminato: nessun vincitore.');
      } else {
        const vincitore = partecipanti[Math.floor(Math.random() * partecipanti.length)];
        await msg.edit({ embeds: [embed.setDescription(`Vincitore: <@${vincitore}>!\nPremio: **${premio}**`)], components: [] });
        await message.channel.send(`🎉 Complimenti <@${vincitore}>! Hai vinto: **${premio}**`);
      }
      delete activeGiveaways[message.channel.id];
    }, durata * 60000);
  });

  client.on('interactionCreate', async (interaction) => {
    if (!interaction.isButton()) return;
    if (interaction.customId !== 'giveaway_enter') return;
    const data = activeGiveaways[interaction.channel.id];
    if (!data) return interaction.reply({ content: 'Giveaway non più attivo.', ephemeral: true });
    if (data.users.has(interaction.user.id)) {
      return interaction.reply({ content: 'Hai già partecipato!', ephemeral: true });
    }
    data.users.add(interaction.user.id);
    await interaction.reply({ content: 'Partecipazione registrata!', ephemeral: true });
  });
};
