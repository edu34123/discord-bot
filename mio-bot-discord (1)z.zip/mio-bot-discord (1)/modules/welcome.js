// modules/welcome.js
const fs = require('fs');
const path = require('path');
const WELCOME_LOG = path.join(__dirname, '../data/welcomed.json');
function loadWelcomed() {
  if (!fs.existsSync(WELCOME_LOG)) return [];
  try { return JSON.parse(fs.readFileSync(WELCOME_LOG, 'utf8')); } catch { return []; }
}
function saveWelcomed(list) {
  fs.mkdirSync(path.dirname(WELCOME_LOG), { recursive: true });
  fs.writeFileSync(WELCOME_LOG, JSON.stringify(list, null, 2));
}

module.exports = (client, config) => {
  client.on('guildMemberAdd', async (member) => {
    const channelId = config.welcomeChannelId;
    if (!channelId) return;
    // Usa fetch per ottenere il canale se non è in cache
    let channel = member.guild.channels.cache.get(channelId);
    if (!channel) {
      try {
        channel = await member.guild.channels.fetch(channelId);
      } catch (e) {
        return;
      }
    }
    if (!channel || !channel.isTextBased()) return;
    // Elimina eventuali vecchi messaggi di benvenuto del botVore
    try {
      const messages = await channel.messages.fetch({ limit: 10 });
      const botWelcomes = messages.filter(m => m.author.id === member.client.user.id && m.embeds.length > 0 && m.embeds[0].title === '👋 Benvenuto!');
      for (const msg of botWelcomes.values()) {
        try { await msg.delete(); } catch {}
      }
    } catch {}
    // Template personalizzato
    let msg = config.welcomeMessage || '👋 Benvenuto <@{userId}>!';
    msg = msg
      .replace('{userId}', member.id)
      .replace('{serverName}', member.guild.name)
      .replace('{memberCount}', member.guild.memberCount);
    // Esempio: invio embed con immagine di benvenuto
    const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
    const avatarUrl = member.user.displayAvatarURL({ extension: 'png', size: 512 });
    const embed = new EmbedBuilder()
      .setTitle('👋 Benvenuto!')
      .setDescription(msg)
      .setColor(0x00BFFF)
      .setImage(avatarUrl); // Mostra l'avatar del nuovo membro

    // Embed di verifica con bottone
    const verifyEmbed = new EmbedBuilder()
      .setTitle('🔒 Verifica richiesta')
      .setDescription('Per accedere al server, clicca il bottone qui sotto per verificarti!')
      .setColor(0x43B581);
    const verifyRow = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('verify_me')
        .setLabel('✅ Verificami')
        .setStyle(ButtonStyle.Success)
    );
    try {
      await channel.send({ embeds: [embed] });
      await channel.send({ embeds: [verifyEmbed], components: [verifyRow] });
      welcomed.push(member.id);
      saveWelcomed(welcomed);
    } catch (err) {
      console.error('Errore invio messaggio di benvenuto:', err);
    }

    // Listener per il bottone di verifica
    client.on('interactionCreate', async interaction => {
      if (!interaction.isButton() || interaction.customId !== 'verify_me') return;
      const verifiedRole = config.verifiedRoleId;
      if (!verifiedRole) return interaction.reply({ content: 'Ruolo verificato non configurato.', ephemeral: true });
      const guildMember = await interaction.guild.members.fetch(interaction.user.id);
      if (guildMember.roles.cache.has(verifiedRole)) {
        return interaction.reply({ content: 'Sei già verificato!', ephemeral: true });
      }
      try {
        await guildMember.roles.add(verifiedRole);
        await interaction.reply({ content: '✅ Sei stato verificato con successo!', ephemeral: true });
      } catch (e) {
        await interaction.reply({ content: '❌ Errore durante la verifica. Contatta lo staff.', ephemeral: true });
      }
    });
  });
};
