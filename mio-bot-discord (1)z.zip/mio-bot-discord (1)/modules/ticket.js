// modules/ticket.js
// Ticket system: invia un messaggio con pulsanti, crea un canale privato quando un utente clicca

const { ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType, PermissionFlagsBits } = require('discord.js');

module.exports = (client, config) => {
  // Comando testuale per inviare il messaggio di ticket (solo admin)
  client.on('messageCreate', async (message) => {
    if (message.author.bot) return;
    if (!config.allowedUsers.includes(message.author.id)) return;
    if (message.content === '!ticketpanel') {
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId('ticket_support')
          .setLabel('Supporto')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('ticket_partnership')
          .setLabel('Partnership')
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('ticket_altro')
          .setLabel('Altro')
          .setStyle(ButtonStyle.Secondary)
      );
      await message.channel.send({
        content: 'Apri un ticket selezionando una delle opzioni:',
        components: [row]
      });
    }
  });

  // Listener per i pulsanti
  client.on('interactionCreate', async (interaction) => {
    try {
      if (!interaction.isButton()) return;
      if (!interaction.customId.startsWith('ticket_')) return;
      const tipo = interaction.customId.replace('ticket_', '');
      // Controlla se l'utente ha già un ticket aperto
      const existing = interaction.guild.channels.cache.find(c => c.name === `ticket-${interaction.user.id}`);
      if (existing) {
        return interaction.reply({ content: 'Hai già un ticket aperto: ' + existing.toString(), ephemeral: true });
      }
      // Crea canale
      const channel = await interaction.guild.channels.create({
        name: `ticket-${interaction.user.id}`,
        type: ChannelType.GuildText,
        permissionOverwrites: [
          { id: interaction.guild.id, deny: [PermissionFlagsBits.ViewChannel] },
          { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] },
          // Aggiungi qui eventuali ruoli staff:
          // { id: '1396459675708297226', allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] },
        ]
      });
      const { EmbedBuilder } = require('discord.js');
      const embed = new EmbedBuilder()
        .setTitle('🎫 Ticket Aperto')
        .setDescription(`Ticket aperto da <@${interaction.user.id}> per: **${tipo}**.\nScrivi qui il tuo messaggio, lo staff ti risponderà appena possibile.`)
        .setColor(0x00BFFF)
        .setTimestamp();
      await channel.send({ embeds: [embed] });
      await interaction.reply({ content: `Ticket creato: ${channel}`, ephemeral: true });
      // Invio pulsante per chiudere il ticket nel canale creato
      const closeRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId('ticket_close')
          .setLabel('🔒 Chiudi Ticket')
          .setStyle(ButtonStyle.Danger)
      );
      await channel.send({ content: 'Quando hai finito, puoi chiudere il ticket:', components: [closeRow] });
    } catch (err) {
      console.error('Errore ticket:', err);
      if (interaction && interaction.reply) {
        try { await interaction.reply({ content: '❌ Errore nella creazione del ticket.', ephemeral: true }); } catch {}
      }
    }
  });

  // INVIA AUTOMATICAMENTE IL PANEL TICKET ALL'AVVIO IN UN CANALE SPECIFICO (con delay per evitare errori di token)
  client.once('ready', async () => {
    setTimeout(async () => {
      try {
        const ticketPanelChannelId = config.ticketPanelChannelId || config.welcomeChannelId;
        const channel = await client.channels.fetch(ticketPanelChannelId);
        if (!channel || !channel.isTextBased()) {
          console.error('Ticket panel: canale non trovato o non testuale');
          return;
        }
        // Debug: log info canale
        console.log('TicketPanelChannelId:', ticketPanelChannelId);
        console.log('Channel:', channel?.id, channel?.type, channel?.isTextBased?.());
        // Elimina qualsiasi vecchio messaggio del bot con pulsanti ticket
        try {
          const messages = await channel.messages.fetch({ limit: 20 });
          console.log('Messaggi trovati:', messages.size);
          const botPanels = messages.filter(m =>
            m.author.id === client.user.id &&
            m.components.length > 0 &&
            m.components.some(row =>
              row.components.some(btn => btn.customId && btn.customId.startsWith('ticket_'))
            )
          );
          console.log('Panel trovati da eliminare:', botPanels.size);
          for (const msg of botPanels.values()) {
            try { await msg.delete(); console.log('Panel eliminato:', msg.id); } catch (e) {
              console.error('Impossibile eliminare un vecchio panel ticket:', e);
              try { await channel.send('❌ Impossibile eliminare un vecchio messaggio panel ticket. Controlla i permessi del bot!'); } catch {}
            }
          }
        } catch (err) {
          console.error('Errore eliminazione vecchi panel ticket:', err);
          try { await channel.send('❌ Errore durante la pulizia dei vecchi panel ticket. Controlla i permessi del bot!'); } catch {}
        }
        // Test permessi prima di inviare il panel
        const perms = channel.permissionsFor(client.user);
        if (!perms || !perms.has('SendMessages')) {
          console.error('Il bot NON ha permesso di inviare messaggi nel canale ticketPanel!');
          try { await channel.send('❌ Il bot NON ha permesso di inviare messaggi in questo canale.'); } catch {}
          return;
        }
        if (!perms.has('ManageMessages')) {
          console.warn('Il bot NON ha permesso di gestire i messaggi nel canale ticketPanel!');
          try { await channel.send('⚠️ Il bot NON ha permesso di gestire i messaggi in questo canale.'); } catch {}
        }
        // Debug: log invio panel
        console.log('Invio panel ticket...');
        const { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');
        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId('ticket_support')
            .setLabel('🛟 Supporto')
            .setStyle(ButtonStyle.Primary),
          new ButtonBuilder()
            .setCustomId('ticket_partnership')
            .setLabel('🤝 Partnership')
            .setStyle(ButtonStyle.Success),
          new ButtonBuilder()
            .setCustomId('ticket_altro')
            .setLabel('❓ Altro')
            .setStyle(ButtonStyle.Secondary)
        );
        const embed = new EmbedBuilder()
          .setTitle('🎫 Apri un Ticket')
          .setDescription(
            'Benvenuto nel supporto!\n\n' +
            '🛟 **Supporto**: Per problemi tecnici, domande o aiuto generale.\n' +
            '🤝 **Partnership**: Per proporre collaborazioni tra community.\n' +
            '❓ **Altro**: Per qualsiasi altra richiesta o comunicazione.\n\n' +
            (config.startNotifyMessage ? `🟢 ${config.startNotifyMessage}\n\n` : '') +
            'Clicca il pulsante più adatto qui sotto e lo staff ti risponderà il prima possibile!'
          )
          .setColor(0x9B59B6)
          .setFooter({ text: 'Lo staff ti risponderà il prima possibile.' });
        await channel.send({
          embeds: [embed],
          components: [row]
        });
        console.log('Ticket panel inviato automaticamente!');
      } catch (err) {
        console.error('Errore invio ticket panel automatico:', err);
      }
    }, 3000); // Attendi 3 secondi
  });

  // Listener per chiusura ticket
  client.on('interactionCreate', async (interaction) => {
    try {
      if (interaction.isButton() && interaction.customId === 'ticket_close') {
        if (!interaction.channel.name.startsWith('ticket-')) {
          return interaction.reply({ content: 'Questo comando può essere usato solo nei canali ticket.', ephemeral: true });
        }
        await interaction.reply({ content: 'Ticket chiuso! Il canale verrà eliminato tra 5 secondi.', ephemeral: true });
        setTimeout(() => {
          interaction.channel.delete().catch(() => {});
        }, 5000);
        return;
      }
    } catch (err) {
      console.error('Errore ticket:', err);
      if (interaction && interaction.reply) {
        try { await interaction.reply({ content: '❌ Errore nella creazione del ticket.', ephemeral: true }); } catch {}
      }
    }
  });
};
