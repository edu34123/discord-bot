// modules/rrole_reactions.js
// Reaction role classico: il bot aggiunge le reaction e gestisce i ruoli
const { EmbedBuilder } = require('discord.js');

// Emoji numeriche unicode
const emojiNumbers = ['1️⃣','2️⃣','3️⃣','4️⃣','5️⃣','6️⃣','7️⃣','8️⃣','9️⃣','🔟'];

module.exports = (client, config) => {
  client.on('interactionCreate', async interaction => {
    if (!interaction.isCommand()) return;
    if (interaction.commandName === 'rrole') {
      const titolo = interaction.options.getString('titolo');
      const descrizione = interaction.options.getString('descrizione');
      const ruoliRaw = interaction.options.getString('ruoli');
      // ruoliRaw: "123456789:Ruolo1,987654321:Ruolo2"
      const ruoli = ruoliRaw.split(',').map((r, i) => {
        const [id, label] = r.split(':');
        return { id: id.trim(), label: (label || id).trim(), emoji: emojiNumbers[i] };
      });
      const embed = new EmbedBuilder()
        .setTitle(titolo)
        .setDescription(ruoli.map(r => `**${r.emoji}** ${r.label}`).join('\n'))
        .setColor(0x00BFFF);
      const msg = await interaction.reply({ embeds: [embed], fetchReply: true });
      for (const r of ruoli) {
        await msg.react(r.emoji);
      }
      // Salva mapping messaggio-ruoli in memoria
      if (!client.rroleMap) client.rroleMap = {};
      client.rroleMap[msg.id] = ruoli;
    }
  });

  client.on('messageReactionAdd', async (reaction, user) => {
    if (user.bot) return;
    if (!client.rroleMap || !client.rroleMap[reaction.message.id]) return;
    const ruoli = client.rroleMap[reaction.message.id];
    const ruolo = ruoli.find(r => r.emoji === reaction.emoji.name);
    if (!ruolo) return;
    const member = await reaction.message.guild.members.fetch(user.id).catch(() => null);
    if (member && !member.roles.cache.has(ruolo.id)) {
      await member.roles.add(ruolo.id).catch(() => {});
    }
  });

  client.on('messageReactionRemove', async (reaction, user) => {
    if (user.bot) return;
    if (!client.rroleMap || !client.rroleMap[reaction.message.id]) return;
    const ruoli = client.rroleMap[reaction.message.id];
    const ruolo = ruoli.find(r => r.emoji === reaction.emoji.name);
    if (!ruolo) return;
    const member = await reaction.message.guild.members.fetch(user.id).catch(() => null);
    if (member && member.roles.cache.has(ruolo.id)) {
      await member.roles.remove(ruolo.id).catch(() => {});
    }
  });
};
