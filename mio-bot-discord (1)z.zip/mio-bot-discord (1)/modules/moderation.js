// modules/moderation.js
// Comandi di moderazione: /ban, /kick, /mute, verifica
const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = (client, config) => {
  // /ban user
  client.on('interactionCreate', async interaction => {
    if (!interaction.isCommand()) return;
    if (interaction.commandName === 'ban') {
      const user = interaction.options.getUser('user');
      const reason = interaction.options.getString('reason') || 'Nessun motivo specificato';
      const member = await interaction.guild.members.fetch(user.id).catch(() => null);
      if (!member) return interaction.reply({ content: 'Utente non trovato.', ephemeral: true });
      // Solo per ruoli autorizzati
      const allowedRoles = config.banAllowedRoles || [];
      if (!interaction.member.roles.cache.some(r => allowedRoles.includes(r.id))) {
        return interaction.reply({ content: 'Non hai il permesso di usare questo comando.', ephemeral: true });
      }
      await member.ban({ reason });
      await interaction.reply({ content: `🔨 <@${user.id}> è stato bannato. Motivo: ${reason}` });
    }
  });
};
