// modules/rrole.js
// Gestione reaction role stile Carl-bot con bottoni
const { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');

module.exports = (client, config) => {
  client.on('interactionCreate', async interaction => {
    if (!interaction.isCommand()) return;
    if (interaction.commandName === 'rrole') {
      const titolo = interaction.options.getString('titolo');
      const descrizione = interaction.options.getString('descrizione');
      const ruoliRaw = interaction.options.getString('ruoli');
      // ruoliRaw: "123456789:Ruolo1,987654321:Ruolo2"
      const ruoli = ruoliRaw.split(',').map((r, i) => {
        const [id, label] = r.split(':');
        return { id: id.trim(), label: (label || id).trim(), emoji: (i+1).toString() };
      });
      const embed = new EmbedBuilder()
        .setTitle(titolo)
        .setDescription(ruoli.map(r => `**${r.emoji}** ${r.label}`).join('\n'))
        .setColor(0x00BFFF);
      const row = new ActionRowBuilder().addComponents(
        ruoli.map(r => new ButtonBuilder()
          .setCustomId(`rrole_${r.id}`)
          .setLabel(r.emoji)
          .setStyle(ButtonStyle.Secondary))
      );
      await interaction.reply({ embeds: [embed], components: [row] });
    }
    // Gestione click bottoni
    if (interaction.isButton() && interaction.customId.startsWith('rrole_')) {
      const roleId = interaction.customId.replace('rrole_', '');
      const member = interaction.member;
      if (!member.guild.roles.cache.has(roleId)) return interaction.reply({ content: 'Ruolo non trovato.', ephemeral: true });
      if (member.roles.cache.has(roleId)) {
        await member.roles.remove(roleId);
        await interaction.reply({ content: 'Ruolo rimosso!', ephemeral: true });
      } else {
        await member.roles.add(roleId);
        await interaction.reply({ content: 'Ruolo assegnato!', ephemeral: true });
      }
    }
  });
};
