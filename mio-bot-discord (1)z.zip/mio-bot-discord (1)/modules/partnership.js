const fs = require("fs");
const path = require("path");

const filePath = path.join(__dirname, "../data/partnerships.json");

module.exports = (client, config) => {
  client.on('messageCreate', async (message) => {
    if (message.author.bot || !message.content) return;
    if (!message.content.startsWith("partner")) return;
    if (!message.member?.permissions?.has("ManageMessages")) return;

    const args = message.content.slice("partner".length).trim();
    if (!args) return message.reply("❌ Scrivi il testo della partnership.");

    // Legge file partnership
    let data = [];
    if (fs.existsSync(filePath)) {
      data = JSON.parse(fs.readFileSync(filePath, "utf8"));
    }

    // Aggiunge nuova partnership
    data.push(`🔹 ${args}`);

    // Salva
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));

    // Modifica o invia il messaggio
    const channel = message.channel;
    const pinned = await channel.messages.fetchPinned().catch(() => null);
    const partnershipList = data.join("\n");

    const embed = {
      title: "🤝 Partnership attive",
      description: partnershipList,
      color: 0x00b0f4,
      footer: { text: `Totale: ${data.length}` },
    };

    const existingMessage = pinned?.find(m => m.author.id === message.client.user.id);
    if (existingMessage) {
      existingMessage.edit({ embeds: [embed] });
    } else {
      const sent = await channel.send({ embeds: [embed] });
      await sent.pin();
    }

    await message.react("✅");
  });
};
