// Klubs info embed and channel cleanup (ENGLISH VERSION)
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType, PermissionFlagsBits } = require('discord.js');

module.exports = (client, config) => {
  const klubsChannelId = config.vcprivateChannelId;
  const allowedRoles = config.banAllowedRoles || [];

  // Send info embed at startup (if not already present)
  client.once('ready', async () => {
    const channel = client.channels.cache.get(klubsChannelId);
    if (!channel || !channel.isTextBased()) return;
    // Delete old klubs embeds
    const messages = await channel.messages.fetch({ limit: 10 });
    for (const msg of messages.values()) {
      if (msg.author.id === client.user.id && msg.embeds.length && msg.embeds[0].title && msg.embeds[0].title.toLowerCase().includes('klubs')) {
        await msg.delete().catch(() => {});
      }
    }
    // Send new embed
    const embed = new EmbedBuilder()
      .setTitle('🗝️ Klubs!')
      .setDescription(
        '***What are they?***\n' +
        '• **Klubs** are private voice rooms where you decide who can join!\n\n' +
        '***What permissions do I need to create one?***\n' +
        '• Click the button below to see the roles allowed to create a klub.\n\n' +
        '**Commands:**\n' +
        '`>create [name]`\n' +
        '`>edit [name]`\n' +
        '`>lock` (only trusted & creator can join)\n' +
        '`>unlock` (everyone can join)\n' +
        '`>trust [@user]` (allow access)\n' +
        '`>delete` (remove klub)'
      )
      .setImage('https://i.imgur.com/1d1ab3313a88ee5e6f4674f37c32a238.png')
      .setColor(0x23272A);
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('klubs_roles')
        .setLabel('📂 Allowed Roles')
        .setStyle(ButtonStyle.Secondary)
    );
    await channel.send({ embeds: [embed], components: [row] });
  });

  // On message: cleanup all except info embed, and create voice if '>create [name]'
  client.on('messageCreate', async (message) => {
    if (message.channel.id !== klubsChannelId) return;
    if (message.author.bot) return;
    // Delete all except info embed
    try {
      const messages = await message.channel.messages.fetch({ limit: 50 });
      for (const msg of messages.values()) {
        if (
          msg.author.id === client.user.id &&
          msg.embeds.length &&
          msg.embeds[0].title &&
          msg.embeds[0].title.toLowerCase().includes('klubs')
        ) continue;
        await msg.delete().catch(() => {});
      }
    } catch (err) {
      console.error('Error cleaning klubs channel:', err);
    }
    // Create voice channel if '>create [name]'
    const createMatch = message.content.match(/^>create\s+(.+)/i);
    if (createMatch) {
      const name = createMatch[1].trim().substring(0, 90);
      try {
        await message.guild.channels.create({
          name: name,
          type: ChannelType.GuildVoice,
          parent: config.klubsCategoryId || null,
          permissionOverwrites: [
            { id: message.guild.id, deny: [PermissionFlagsBits.Connect] },
            { id: message.author.id, allow: [PermissionFlagsBits.Connect, PermissionFlagsBits.ManageChannels] },
            // Optionally allow roles from config
            ...allowedRoles.map(roleId => ({ id: roleId, allow: [PermissionFlagsBits.Connect] }))
          ]
        });
      } catch (err) {
        console.error('Error creating klub voice channel:', err);
      }
    }
  });

  // Button: show allowed roles
  client.on('interactionCreate', async (interaction) => {
    if (!interaction.isButton()) return;
    if (interaction.customId !== 'klubs_roles') return;
    const embed = new EmbedBuilder()
      .setTitle('📂 Allowed Roles for Klubs')
      .setDescription(allowedRoles.length ? allowedRoles.map(r => `<@&${r}>`).join('\n') : 'No roles configured.')
      .setColor(0x5865F2);
    await interaction.reply({ embeds: [embed], ephemeral: true });
  });
};