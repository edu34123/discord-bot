// modules/voiceNotify.js
// Notifica in un canale testuale quando un utente entra in una vocale specifica

module.exports = (client, config) => {
  // ID della vocale da monitorare e del canale dove inviare la notifica
  const voiceChannelId = config.voiceNotifyChannelId; // ID della vocale da monitorare
  const notifyTextChannelId = config.voiceNotifyTextChannelId; // ID del canale testuale per la notifica

  if (!voiceChannelId || !notifyTextChannelId) return;

  client.on('voiceStateUpdate', async (oldState, newState) => {
    // Utente entra nella vocale specifica
    if (
      (!oldState.channelId || oldState.channelId !== voiceChannelId) &&
      newState.channelId === voiceChannelId
    ) {
      const user = newState.member.user;
      const textChannel = newState.guild.channels.cache.get(notifyTextChannelId);
      if (textChannel && textChannel.isTextBased()) {
        textChannel.send(`🔔 <@${user.id}> è entrato nel canale vocale!`);
      }
    }
  });
};
