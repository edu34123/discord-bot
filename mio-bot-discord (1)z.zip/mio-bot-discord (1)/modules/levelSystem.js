// modules/levelSystem.js
// Sistema di livelli XP per utenti Discord
const fs = require('fs');
const path = require('path');
const LEVELS_FILE = path.join(__dirname, '../data/levels.json');

function loadLevels() {
  if (!fs.existsSync(LEVELS_FILE)) return {};
  try { return JSON.parse(fs.readFileSync(LEVELS_FILE, 'utf8')); } catch { return {}; }
}
function saveLevels(levels) {
  fs.mkdirSync(path.dirname(LEVELS_FILE), { recursive: true });
  fs.writeFileSync(LEVELS_FILE, JSON.stringify(levels, null, 2));
}

module.exports = (client, config) => {
  let levels = loadLevels();

  client.on('messageCreate', message => {
    if (message.author.bot || !message.guild) return;
    const id = message.author.id;
    if (!levels[id]) levels[id] = { xp: 0, level: 0 };
    levels[id].xp += Math.floor(Math.random() * 8) + 3; // XP random
    // Soglie personalizzate
    const thresholds = [1, 5, 10, 15, 20, 30, 40, 50, 75, 100, 200];
    let newLevel = 0;
    for (let i = 0; i < thresholds.length; i++) {
      if (levels[id].xp >= thresholds[i] * 100) newLevel = thresholds[i];
    }
    if (levels[id].xp >= 200 * 100) newLevel = Math.floor(levels[id].xp / 100);
    if (newLevel > levels[id].level) {
      levels[id].level = newLevel;
      message.channel.send(`🎉 <@${id}> è salito al livello ${newLevel}!`);
    }
    saveLevels(levels);
  });

  client.on('interactionCreate', async interaction => {
    if (!interaction.isCommand()) return;
    if (interaction.commandName === 'level') {
      const user = interaction.options.getUser('user') || interaction.user;
      const data = levels[user.id] || { xp: 0, level: 0 };
      await interaction.reply({ content: `🔹 <@${user.id}> è al livello ${data.level} con ${data.xp} XP.`, ephemeral: true });
    }
    if (interaction.commandName === 'leaderboard') {
      // Ordina per XP decrescente
      const sorted = Object.entries(levels)
        .sort((a, b) => b[1].xp - a[1].xp)
        .slice(0, 15);
      let desc = '';
      let pos = 1;
      for (const [userId, data] of sorted) {
        const member = await interaction.guild.members.fetch(userId).catch(() => null);
        const name = member ? member.user.tag : `account${userId}`;
        desc += `${pos}. ${name}: Level ${data.level} - ${data.xp} XP\n`;
        pos++;
      }
      const { EmbedBuilder } = require('discord.js');
      const embed = new EmbedBuilder()
        .setTitle('Live Leaderboard')
        .setDescription('Find all the users levels here. Updated every time.\n\n**Leaderboard**\n' + desc)
        .setColor(0x00BFFF)
        .setTimestamp();
      await interaction.reply({ embeds: [embed], ephemeral: false });
    }
  });
};
