// Keep-alive web server for Replit
const express = require('express');
const app = express();
const port = process.env.PORT || 3000;

app.get('/', (req, res) => res.send('Bot is running!'));
app.listen(port, () => console.log('Web server active on port ' + port));

const { Client, GatewayIntentBits, Collection, ChannelType } = require('discord.js');
const fs = require('fs');
const path = require('path');
const config = require('./config.json');
console.log('Config:', config); // Debug config

// Global error handling for startup debug
process.on('uncaughtException', err => { console.error('UNCAUGHT', err); });
process.on('unhandledRejection', err => { console.error('UNHANDLED', err); });

const client = new Client({ intents: [
  GatewayIntentBits.Guilds,
  GatewayIntentBits.GuildMessages,
  GatewayIntentBits.MessageContent,
  GatewayIntentBits.GuildMembers // Needed for guildMemberAdd
] });
client.commands = new Collection();

// Load commands
const commandFiles = fs.readdirSync('./commands').filter(file => file.endsWith('.js'));
for (const file of commandFiles) {
  const command = require(`./commands/${file}`);
  if (!command.data) continue; // Skip disabled commands
  client.commands.set(command.data.name, command);
}

// Load events
const eventFiles = fs.readdirSync('./events').filter(file => file.endsWith('.js'));
for (const file of eventFiles) {
  const event = require(`./events/${file}`);
  if (event.once) {
    client.once(event.name, (...args) => event.execute(...args, client));
  } else {
    client.on(event.name, (...args) => event.execute(...args, client));
  }
}

// Unified text command handler
client.on('messageCreate', async (message) => {
  if (message.author.bot) return;
  if (!config.allowedUsers.includes(message.author.id)) return;

  if (message.content === '!restart') {
    await message.reply('♻️ Restarting...');
    process.exit(1);
  }
  if (message.content === '!shutdown') {
    await message.reply('🔌 Shutting down...');
    process.exit(0);
  }
  if (message.content.startsWith('!creauncanale')) {
    const args = message.content.split(' ');
    if (args.length < 3) {
      return message.reply('❌ Usage: !creauncanale <name> <text|voice>');
    }
    const name = args[1];
    let type;
    if (args[2] === 'voice') {
      type = 2; // ChannelType.GuildVoice
    } else if (args[2] === 'text') {
      type = 0; // ChannelType.GuildText
    } else {
      return message.reply('❌ Invalid type. Use "text" or "voice".');
    }
    try {
      await message.guild.channels.create({ name: name, type: type });
      await message.reply(`✅ Channel "${name}" created!`);
    } catch (error) {
      console.error(error);
      await message.reply('❌ Error creating channel.');
    }
  }
  if (message.content === '!test') {
    await message.reply('✅ Bot is working!');
  }
  if (message.content === '!diagnostica') {
    let result = '🛠️ Bot diagnostics:\n';
    // Basic permission test
    const canSend = message.channel.permissionsFor(message.guild.members.me).has('SendMessages');
    const canManageChannels = message.guild.members.me.permissions.has('ManageChannels');
    result += canSend ? '✅ Bot can send messages\n' : '❌ Bot CANNOT send messages\n';
    result += canManageChannels ? '✅ Bot can manage channels\n' : '❌ Bot CANNOT manage channels\n';
    // Intent test
    const hasMessageContent = client.options.intents.has(GatewayIntentBits.MessageContent);
    result += hasMessageContent ? '✅ MessageContent intent ENABLED\n' : '❌ MessageContent intent DISABLED\n';
    // Allowed user test
    const isAllowed = config.allowedUsers.includes(message.author.id);
    result += isAllowed ? '✅ You are authorized to use commands\n' : '❌ You are NOT authorized to use commands\n';
    // Welcome channel test
    let welcomeTest = '';
    if (config.welcomeChannelId) {
      const welcomeChannel = message.guild.channels.cache.get(config.welcomeChannelId);
      if (welcomeChannel && welcomeChannel.isTextBased()) {
        const canSendWelcome = welcomeChannel.permissionsFor(message.guild.members.me).has('SendMessages');
        welcomeTest = canSendWelcome ? '✅ Bot can send messages in the welcome channel' : '❌ Bot CANNOT send messages in the welcome channel';
      } else {
        welcomeTest = '❌ Welcome channel not found or not text-based';
      }
    } else {
      welcomeTest = 'ℹ️ Welcome channel not configured';
    }
    result += welcomeTest + '\n';
    await message.reply(result);
  }
  if (message.content === '!testwelcome') {
    const channelId = config.welcomeChannelId;
    let channel = message.guild.channels.cache.get(channelId);
    if (!channel) {
      try {
        channel = await message.guild.channels.fetch(channelId);
      } catch (e) {
        return message.reply('❌ Welcome channel not found.');
      }
    }
    if (!channel || !channel.isTextBased()) return message.reply('❌ The welcome channel is not text-based.');
    let msg = config.welcomeMessage || '👋 Welcome <@{userId}>!';
    msg = msg
      .replace('{userId}', message.author.id)
      .replace('{serverName}', message.guild.name)
      .replace('{memberCount}', message.guild.memberCount);
    try {
      await channel.send(msg);
      await message.reply('✅ Welcome message sent!');
    } catch (err) {
      console.error('Error sending test welcome:', err);
      await message.reply('❌ Error sending welcome message.');
    }
  }
  if (message.content.startsWith('!say ')) {
    const text = message.content.slice(5).trim();
    if (!text) return message.reply('❌ You must specify a message.');
    await message.channel.send(text);
  }
  // Custom text command handler from commands folder
  if (message.content.startsWith('!')) {
    const [cmd, ...args] = message.content.slice(1).split(/\s+/);
    const command = client.commands.get(cmd);
    if (command && typeof command.execute === 'function') {
      try {
        await command.execute(message, args);
      } catch (err) {
        console.error('Command error', cmd, err);
        await message.reply('❌ Error executing command.');
      }
    }
  }
});
// Startup event handler
client.once('ready', () => {
  console.log(`Bot ready as ${client.user.tag}`);
  client.user.setActivity(config.activity || 'Waiting for commands', { type: 'WATCHING' });
});

// Initialize custom modules (once, outside events)
const modulesPath = path.join(__dirname, 'modules');
if (fs.existsSync(modulesPath)) {
  const moduleFiles = fs.readdirSync(modulesPath).filter(file => file.endsWith('.js'));
  for (const file of moduleFiles) {
    require(`./modules/${file}`)(client, config);
  }
}

// Start the bot
client.login(process.env.TOKEN || config.token);
