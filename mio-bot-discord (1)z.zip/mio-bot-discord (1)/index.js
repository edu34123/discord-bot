const { Client, GatewayIntentBits, Collection, ChannelType } = require('discord.js');
const fs = require('fs');
const path = require('path');
const config = require('./config.json');
console.log('Config:', config); // Debug config

// Gestione errori globali per debug avvio
process.on('uncaughtException', err => { console.error('UNCAUGHT', err); });
process.on('unhandledRejection', err => { console.error('UNHANDLED', err); });

const client = new Client({ intents: [
  GatewayIntentBits.Guilds,
  GatewayIntentBits.GuildMessages,
  GatewayIntentBits.MessageContent,
  GatewayIntentBits.GuildMembers // Intent necessario per guildMemberAdd
] });
client.commands = new Collection();

// Carica comandi
const commandFiles = fs.readdirSync('./commands').filter(file => file.endsWith('.js'));
for (const file of commandFiles) {
  const command = require(`./commands/${file}`);
  if (!command.data) continue; // Salta i comandi disabilitati
  client.commands.set(command.data.name, command);
}

// Carica eventi
const eventFiles = fs.readdirSync('./events').filter(file => file.endsWith('.js'));
for (const file of eventFiles) {
  const event = require(`./events/${file}`);
  if (event.once) {
    client.once(event.name, (...args) => event.execute(...args, client));
  } else {
    client.on(event.name, (...args) => event.execute(...args, client));
  }
}

// Unifica la gestione dei comandi testuali in un solo listener
client.on('messageCreate', async (message) => {
  if (message.author.bot) return;
  if (!config.allowedUsers.includes(message.author.id)) return;

  if (message.content === '!restart') {
    await message.reply('♻️ Riavvio in corso...');
    process.exit(1); // Usa exit code 1 per forzare il restart con nodemon
  }
  if (message.content === '!shutdown') {
    await message.reply('🔌 Spegnimento in corso...');
    process.exit(0);
  }
  if (message.content.startsWith('!creauncanale')) {
    const args = message.content.split(' ');
    if (args.length < 3) {
      return message.reply('❌ Usa: !creauncanale <nome> <text|voice>');
    }
    const nome = args[1];
    let tipo;
    if (args[2] === 'voice') {
      tipo = 2; // ChannelType.GuildVoice
    } else if (args[2] === 'text') {
      tipo = 0; // ChannelType.GuildText
    } else {
      return message.reply('❌ Tipo non valido. Usa "text" o "voice".');
    }
    try {
      await message.guild.channels.create({ name: nome, type: tipo });
      await message.reply(`✅ Canale "${nome}" creato!`);
    } catch (error) {
      console.error(error);
      await message.reply('❌ Errore nella creazione del canale.');
    }
  }
  if (message.content === '!test') {
    await message.reply('✅ Il bot funziona!');
  }
  if (message.content === '!diagnostica') {
    let result = '🛠️ Diagnostica bot:\n';
    // Test permessi base
    const canSend = message.channel.permissionsFor(message.guild.members.me).has('SendMessages');
    const canManageChannels = message.guild.members.me.permissions.has('ManageChannels');
    result += canSend ? '✅ Il bot può inviare messaggi\n' : '❌ Il bot NON può inviare messaggi\n';
    result += canManageChannels ? '✅ Il bot può gestire i canali\n' : '❌ Il bot NON può gestire i canali\n';
    // Test intent
    const hasMessageContent = client.options.intents.has(GatewayIntentBits.MessageContent);
    result += hasMessageContent ? '✅ Intent MessageContent ATTIVO\n' : '❌ Intent MessageContent NON attivo\n';
    // Test allowed user
    const isAllowed = config.allowedUsers.includes(message.author.id);
    result += isAllowed ? '✅ Sei autorizzato a usare i comandi\n' : '❌ Non sei autorizzato a usare i comandi\n';
    // Test canale benvenuto
    let welcomeTest = '';
    if (config.welcomeChannelId) {
      const welcomeChannel = message.guild.channels.cache.get(config.welcomeChannelId);
      if (welcomeChannel && welcomeChannel.isTextBased()) {
        const canSendWelcome = welcomeChannel.permissionsFor(message.guild.members.me).has('SendMessages');
        welcomeTest = canSendWelcome ? '✅ Il bot può inviare messaggi nel canale di benvenuto' : '❌ Il bot NON può inviare messaggi nel canale di benvenuto';
      } else {
        welcomeTest = '❌ Canale di benvenuto non trovato o non testuale';
      }
    } else {
      welcomeTest = 'ℹ️ Canale di benvenuto non configurato';
    }
    result += welcomeTest + '\n';
    await message.reply(result);
  }
  if (message.content === '!testwelcome') {
    const channelId = config.welcomeChannelId;
    let channel = message.guild.channels.cache.get(channelId);
    if (!channel) {
      try {
        channel = await message.guild.channels.fetch(channelId);
      } catch (e) {
        return message.reply('❌ Canale di benvenuto non trovato.');
      }
    }
    if (!channel || !channel.isTextBased()) return message.reply('❌ Il canale di benvenuto non è testuale.');
    let msg = config.welcomeMessage || '👋 Benvenuto <@{userId}>!';
    msg = msg
      .replace('{userId}', message.author.id)
      .replace('{serverName}', message.guild.name)
      .replace('{memberCount}', message.guild.memberCount);
    try {
      await channel.send(msg);
      await message.reply('✅ Messaggio di benvenuto inviato!');
    } catch (err) {
      console.error('Errore invio test welcome:', err);
      await message.reply('❌ Errore nell\'invio del messaggio di benvenuto.');
    }
  }
  if (message.content.startsWith('!say ')) {
    const text = message.content.slice(5).trim();
    if (!text) return message.reply('❌ Devi specificare un messaggio.');
    await message.channel.send(text);
  }
  // Gestione comandi testuali custom dalla cartella commands
  if (message.content.startsWith('!')) {
    const [cmd, ...args] = message.content.slice(1).split(/\s+/);
    const command = client.commands.get(cmd);
    if (command && typeof command.execute === 'function') {
      try {
        await command.execute(message, args);
      } catch (err) {
        console.error('Errore comando', cmd, err);
        await message.reply('❌ Errore durante l\'esecuzione del comando.');
      }
    }
  }
});
// Gestione eventi di avvio
client.once('ready', () => {
  console.log(`Bot pronto come ${client.user.tag}`);
  client.user.setActivity(config.activity || 'in attesa di comandi', { type: 'WATCHING' });
});

// Inizializza i moduli custom (solo una volta, fuori dagli eventi)
const modulesPath = path.join(__dirname, 'modules');
if (fs.existsSync(modulesPath)) {
  const moduleFiles = fs.readdirSync(modulesPath).filter(file => file.endsWith('.js'));
  for (const file of moduleFiles) {
    require(`./modules/${file}`)(client, config);
  }
}

// Avvia il bot
client.login(config.token);
